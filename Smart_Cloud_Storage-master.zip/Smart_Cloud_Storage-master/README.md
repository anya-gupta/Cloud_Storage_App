# Smart_Cloud_Storage
 
 GLA UNIVERSITY  Mini Project  2020-21

 
 An Android Applicaton For storing image Vedio Song Pdf on Cloud.
 
 Using  cloud for storage - Firbase , Language - Java and Android Studio platform
 
 # Setup guide
  
  git clone https://github.com/jainishank733/Smart_Cloud_Storage.git
  
  login on Firbase console
  
  In Android Studio > tool > Firebase > connect
  
  Download google.jason file in App file of the project.
  
  Run the project..
